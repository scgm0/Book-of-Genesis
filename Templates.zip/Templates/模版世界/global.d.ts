
interface EventEmitter {
	get defaultMaxListeners(): number;
	set defaultMaxListeners(n: number);
	addListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
	emit(eventName: string | symbol, ...args: any[]): boolean;
	setMaxListeners(n: number): this;
	getMaxListeners(): number;
	listenerCount(eventName: string | symbol): number;
	eventNames(): (string | symbol)[];
	listeners(eventName: string | symbol): Function[];
	off(eventName: string | symbol, listener: (...args: any[]) => void): this;
	on(eventName: string | symbol, listener: (...args: any[]) => void, prepend?: boolean): this;
	removeAllListeners(eventName: string | symbol): this;
	removeListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
	once(eventName: string | symbol, listener: (...args: any[]) => void): this;
	prependListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
	prependOnceListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
	rawListeners(eventName: string | symbol): Function[];
}

declare module "events" {
	export class EventEmitter {
		get defaultMaxListeners(): number;
		set defaultMaxListeners(n: number);
		addListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
		emit(eventName: string | symbol, ...args: any[]): boolean;
		setMaxListeners(n: number): this;
		getMaxListeners(): number;
		listenerCount(eventName: string | symbol): number;
		eventNames(): (string | symbol)[];
		listeners(eventName: string | symbol): Function[];
		off(eventName: string | symbol, listener: (...args: any[]) => void): this;
		on(eventName: string | symbol, listener: (...args: any[]) => void, prepend?: boolean): this;
		removeAllListeners(eventName: string | symbol): this;
		removeListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
		once(eventName: string | symbol, listener: (...args: any[]) => void): this;
		prependListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
		prependOnceListener(eventName: string | symbol, listener: (...args: any[]) => void): this;
		rawListeners(eventName: string | symbol): Function[];
	}
	export interface WrappedFunction extends Function {
		listener: (...args: any[]) => void;
	}
	export default EventEmitter;
}

declare module "audio" {
	export class AudioPlayer {
		finishedCallback: () => void;
		get duration(): number;
		get currentPosition(): number;
		get isPlaying(): number;
		get loop(): boolean;
		set loop(value: boolean);
		play(fromPosition: number): this;
		pause(): this;
		seek(position: number): this;
		stop(): this;
		setAudioPath(path: string): this;
		dispose(): void;

		static playFile(path: string, loop?: boolean, fromPosition?: number, finishedCallback?: () => void): AudioPlayer;
	}
	export default AudioPlayer;
}

declare function setTimeout(callback: (...args: any[]) => void, ms: number, ...args: any[]): number;
declare function clearTimeout(timeoutId: number): void;

declare function setInterval(callback: (...args: any[]) => void, ms: number, ...args: any[]): number;
declare function clearInterval(intervalId: number): void;

declare interface ImportMeta {
	url: string;
}

/**
 * 声明世界事件的命名空间
 */
declare namespace World {
	/**
	 * 定义世界事件类型
	 */
	export enum EventType {
		/** 世界准备就绪事件 */
		Ready = "0",
		/** 世界帧事件 */
		Tick = "1",
		/** 世界退出事件 */
		Exit = "2",
		/** 命令事件 */
		Command = "3",
		/** 左侧按钮点击事件 */
		LeftButtonClick = "4",
		/** 右侧按钮点击事件 */
		RightButtonClick = "5",
		/** 文本链接点击事件 */
		TextUrlClick = "6"
	}

	/**
	 * 定义文本类型
	 */
	export enum TextType {
		All,
		Title,
		LeftText,
		CenterText,
		RightText
	}
}

/** 
 * 世界事件接口 
 */
interface WorldEvent extends EventEmitter {
	/**
	 * 监听世界准备就绪事件
	 * 
	 * @event ready
	 */
	on(event: World.EventType.Ready, listener: () => void): this;

	/**
	 * 监听世界帧事件
	 * 
	 * @event tick
	 */
	on(event: World.EventType.Tick, listener: () => void): this;

	/**
	 * 监听世界退出事件
	 * 
	 * @event exit
	 * @param exitCode 退出码
	 */
	on(event: World.EventType.Exit, listener: (exitCode: number) => void): this;

	/**
	 * 监听命令事件
	 * 
	 * @event command
	 * @param command 接收到的命令字符串
	 */
	on(event: World.EventType.Command, listener: (command: string) => void): this;

	/**
	 * 监听左侧或右侧按钮点击事件
	 * 
	 * @event leftButtonClick
	 * @event rightButtonClick
	 * @param text 按钮文本
	 * @param index 按钮索引
	 * @param id 按钮 ID
	 */
	on(event: World.EventType.LeftButtonClick | World.EventType.RightButtonClick, listener: (text: string, index: number, id: number) => void): this;

	/**
	 * 监听文本链接点击事件
	 * 
	 * @event textUrlClick
	 * @param meta 文本链接元数据，可以是字符串或对象
	 * @param index 文本链接索引
	 */
	on(event: World.EventType.TextUrlClick, listener: (meta: string | object, index: number) => void): this;
}

/** 
 * 世界对象 
 */
declare namespace World {
	/** 游戏版本 */
	const gameVersion: string;
	/** 世界事件 */
	const event: WorldEvent;
	/** 世界信息 */
	const info: {
		/** 名称 */
		name: string;
		/** 作者 */
		author: string;
		/** 主脚本 */
		main: string;
		/** 图标 */
		icon: string;
		/** 版本 */
		version: string;
		/** 介绍 */
		description: string;
		/** 是否加密 */
		is_encrypt: boolean;
	};

	function print(...args: any[]): void;
	/**
	 * 设置世界标题
	 * 
	 * @param title 标题
	 */
	function setTitle(title: string): void;
	/**
	 * 设置背景颜色
	 * 
	 * @param colorHex 16进制颜色字符串
	 */
	function setBackgroundColor(colorHex: string): void;
	/**
	 * 设置背景纹理
	 * 
	 * @param texturePath 纹理路径
	 * @param textureFilter 纹理过滤模式，0为双线性插值，1为最近邻插值，默认为0
	 */
	function setBackgroundTexture(texturePath: string, textureFilter?: number): void;

	function addLeftText(text: string): void;
	function addCenterText(text: string): void;
	function addRightText(text: string): void;
	function setLeftText(text: string): void;
	function setCenterText(text: string): void;
	function setRightText(text: string): void;
	function setLeftStretchRatio(ratio: number): void;
	function setCenterStretchRatio(ratio: number): void;
	function setRightStretchRatio(ratio: number): void;

	function addLeftButton(button: string): number;
	function addRightButton(button: string): number;
	function setLeftButtons(buttons: string[]): number[];
	function setRightButtons(buttons: string[]): number[];
	function removeLeftButtonByIndex(index: number): void;
	function removeRightButtonByIndex(index: number): void;
	function removeButtonById(id: number): void;

	/**
	 * 设置命令行提示文本
	 * 
	 * @param placeholderText 提示文本
	 */
	function setCommandPlaceholderText(placeholderText: string): void;

	function setTextBackgroundColor(type: World.TextType, colorHex: string): void;
	function setTextFontColor(type: World.TextType, colorHex: string): void;

	function setSaveValue(section: string, key: string, value: any): void;
	function setGlobalSaveValue(section: string, key: string, value: any): void;
	function getSaveValue<T>(section: string, key: string, defaultValue?: T): T;
	function getGlobalSaveValue<T>(section: string, key: string, defaultValue?: T): T;

	/** 
	 * 比较两个版本号的大小
	 * 
	 * @param version1 - 版本号字符串1
	 * @param version2 - 版本号字符串2
	 * @returns 1 表示 version1 大于 version2，0 表示相等，-1 表示 version1 小于 version2
	 */
	function versionCompare(version1: string, version2: string): number;

	/**
	 * 退出程序，并可指定退出码。
	 * 
	 * @param exitCode - 指定退出码，默认为0
	 */
	function exit(exitCode?: number): void;
}
