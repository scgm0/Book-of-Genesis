import Utils from "./lib.js";
import AudioPlayer from "audio";

let a = AudioPlayer.playFile("gull_1.wav");
World.print(a.finishedCallback = function(){
	World.print(Utils, this)
});

let t = Date.now();
let id = setTimeout((...a1)=>{
		World.print(...a1, (Date.now()-t)/1000);
		World.addRightButton("777");
	}, 1000, "a1", World.info.version);
World.setBackgroundTexture("icon.png", World.FilterType.Nearest);
World.event.on(World.EventType.Ready, () => {
	// clearTimeout(id);
	World.print(import.meta.url, Date.now()-t);
	World.setBackgroundTexture(null);
	World.setBackgroundColor("#008080");
	t = Date.now();
});

World.event.on(World.EventType.LeftButtonClick, (str, i) => {
	if(i == 0){
		World.addRightText(World.getSaveValue("test", "m1"));
		World.removeRightButtonByIndex(0);
	}
});

World.event.on(World.EventType.Command, text => {
	World.setCommandPlaceholderText(text);
	World.setSaveValue("test", "m1", text)
});

World.event.on(World.EventType.RightButtonClick, (str, i) => {
	World.print(str);
	if(str == "777") {
		World.setLeftText(`
[img filter=nearest]icon.png[/img]
[i]好好好[/i]
[bgcolor=red][url={"data": "yes"}]确定[/url][url=no]取消[/url][/bgcolor]
[color=#ff00ff][url]无[/url][/color]
		`)
	}
});

World.event.on(World.EventType.TextUrlClick, (meta, i) => {
	switch(typeof meta){
		case "object":
			World.addRightText(`${meta?.data}, ${i}`);
			break;
		case "string":
			World.addRightText(`${meta}, ${i}`);
			break;
	}
	World.addRightText("\n");
})

let i = 0;
World.event.on(World.EventType.Tick, () => {
	if(Date.now()-t <= 1000){
		i++
	} else {
		World.setTitle(`${World.info.name}-${Date.now()}`);
		World.addCenterText(`\n${(Date.now()-t)/1000}`);
		t = Date.now();
		i = 0;
	}
});

World.event.on(World.EventType.Exit, e => {
	World.setBackgroundTexture(null);
	World.print(e, (Date.now()-t)/1000, i);
});

World.print(id, World.info.version);

World.print(World.setLeftButtons(["555", "666"]));

World.setCommandPlaceholderText("输入命令");

World.setCenterStretchRatio(2);

World.setCenterText("[b]金木水火土[/b]");

World.setTextBackgroundColor(World.TextType.All, "#2626268A")

for(let i = 0; i < 10; i++){
	World.addRightButton(i**i)
}

World.print("gameVersion", World.gameVersion, World.versionCompare(World.gameVersion, "1.19.4"));

setTimeout((t)=>{
		World.print("out", Date.now()-t);
}, 11, Date.now());
